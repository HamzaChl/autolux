import { useLocalSearchParams, useRouter } from "expo-router";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from "react-native";
import MapView, { Marker } from "react-native-maps";
import { theme } from "@/constants/theme";

export default function PreviewRideScreen() {
  const { pickup, destination } = useLocalSearchParams();
  const router = useRouter();

  // coords fake pour la démo
  const pickupCoords = { latitude: 50.8503, longitude: 4.3517 }; // Bruxelles
  const destCoords = { latitude: 50.845, longitude: 4.35 };

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: pickupCoords.latitude,
          longitude: pickupCoords.longitude,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        }}
      >
        <Marker coordinate={pickupCoords} title="Départ" pinColor="green" />
        <Marker
          coordinate={destCoords}
          title="Destination"
          pinColor={theme.colors.primary}
        />
      </MapView>

      <View style={styles.bottomSheet}>
        <Text style={styles.title}>Aperçu du trajet</Text>
        <Text style={styles.info}>Départ: {pickup}</Text>
        <Text style={styles.info}>Destination: {destination}</Text>
        <Text style={styles.info}>Durée estimée: 12 min</Text>
        <Text style={styles.info}>Prix estimé: 18 €</Text>

        <TouchableOpacity
          style={styles.button}
          onPress={() => router.push("/ride/confirm")}
        >
          <Text style={styles.buttonText}>Confirmer la course</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height,
  },
  bottomSheet: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: theme.colors.card,
    padding: 20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    color: theme.colors.text,
    marginBottom: 10,
  },
  info: { color: theme.colors.text, marginBottom: 5 },
  button: {
    backgroundColor: theme.colors.primary,
    padding: 15,
    borderRadius: 10,
    marginTop: 10,
    alignItems: "center",
  },
  buttonText: { color: "#fff", fontWeight: "bold" },
});
