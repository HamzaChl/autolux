import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { theme } from "@/constants/theme";
import { useRouter } from "expo-router";

export default function ConfirmRideScreen() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Confirmation 🚖</Text>
      <Text style={styles.info}>Chauffeur: John Doe</Text>
      <Text style={styles.info}>Véhicule: Mercedes E-Class</Text>
      <Text style={styles.info}>Prix: 18 €</Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => alert("Course confirmée ✅")}
      >
        <Text style={styles.buttonText}>Commander</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.button, { backgroundColor: theme.colors.accent }]}
        onPress={() => router.back()}
      >
        <Text style={styles.buttonText}>Retour</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background, padding: 20 },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: theme.colors.text,
    marginBottom: 20,
  },
  info: { color: theme.colors.text, marginBottom: 10, fontSize: 16 },
  button: {
    backgroundColor: theme.colors.primary,
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 10,
  },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});
