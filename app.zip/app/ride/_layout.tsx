import { Stack } from "expo-router";
import { theme } from "@/constants/theme";

export default function RideLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: theme.colors.card },
        headerTintColor: theme.colors.text,
        headerTitleAlign: "center",
      }}
    >
      <Stack.Screen name="select" options={{ title: "Planifier un trajet" }} />
      <Stack.Screen name="preview" options={{ title: "Aperçu du trajet" }} />
      <Stack.Screen name="confirm" options={{ title: "Confirmation" }} />
    </Stack>
  );
}
