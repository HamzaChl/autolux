import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { useRouter } from "expo-router";
import { theme } from "@/constants/theme";

export default function SelectRideScreen() {
  const [pickup, setPickup] = useState("Ma position actuelle");
  const [destination, setDestination] = useState("");
  const router = useRouter();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Planifier votre trajet 🚖</Text>

      <TextInput
        style={styles.input}
        placeholder="Point de départ"
        value={pickup}
        onChangeText={setPickup}
      />

      <TextInput
        style={styles.input}
        placeholder="Destination"
        value={destination}
        onChangeText={setDestination}
      />

      <TouchableOpacity
        style={styles.button}
        onPress={() => {
          if (destination.trim() !== "") {
            router.push({
              pathname: "/ride/preview",
              params: { pickup, destination },
            });
          }
        }}
      >
        <Text style={styles.buttonText}>Voir l’aperçu</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background, padding: 20 },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: theme.colors.text,
    marginBottom: 20,
  },
  input: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  button: {
    backgroundColor: theme.colors.primary,
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});
