import { useEffect, useState, useMemo, useRef } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import MapView, { Marker } from "react-native-maps";
import * as Location from "expo-location";
import BottomSheet from "@gorhom/bottom-sheet";
import { theme } from "@/constants/theme";

type Coordinates = {
  latitude: number;
  longitude: number;
};

export default function HomeScreen() {
  const [location, setLocation] = useState<Coordinates | null>(null);
  const [destination, setDestination] = useState("");
  const bottomSheetRef = useRef<BottomSheet>(null);

  const snapPoints = useMemo(() => ["20%", "50%"], []);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        console.warn("Permission refusée");
        return;
      }

      let loc = await Location.getCurrentPositionAsync({});
      setLocation({
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      });
    })();
  }, []);

  return (
    <View style={styles.container}>
      {/* MAP */}
      {location && (
        <MapView
          style={styles.map}
          initialRegion={{
            latitude: location.latitude,
            longitude: location.longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          }}
          showsUserLocation
        >
          <Marker
            coordinate={location}
            title="Vous êtes ici"
            pinColor={theme.colors.primary}
          />
        </MapView>
      )}

      {/* BOTTOM SHEET */}
      <BottomSheet ref={bottomSheetRef} index={0} snapPoints={snapPoints}>
        <View style={styles.sheetContent}>
          <Text style={styles.title}>Où voulez-vous aller ?</Text>

          <TextInput
            style={styles.input}
            placeholder="Saisir une destination"
            placeholderTextColor={theme.colors.muted}
            value={destination}
            onChangeText={setDestination}
          />

          <TouchableOpacity
            style={styles.button}
            onPress={() => alert(`Destination choisie: ${destination}`)}
          >
            <Text style={styles.buttonText}>Voir l’aperçu</Text>
          </TouchableOpacity>
        </View>
      </BottomSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background },
  map: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height,
  },
  sheetContent: { flex: 1, padding: 20 },
  title: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 10,
    color: theme.colors.text,
  },
  input: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  button: {
    backgroundColor: theme.colors.primary,
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonText: { color: "#fff", fontWeight: "bold" },
});
