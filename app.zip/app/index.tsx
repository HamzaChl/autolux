import { Redirect } from "expo-router";

export default function Index() {
  // 🚀 Redirige direct vers login
  return <Redirect href="/(auth)/login" />;
}
